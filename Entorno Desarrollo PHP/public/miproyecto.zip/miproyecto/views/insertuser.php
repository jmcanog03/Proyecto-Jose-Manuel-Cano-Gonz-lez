<html>
    <h1>Insertar Usuario</h1>
    <form action='/miproyecto/index.php?controller=UserController&action=addUser' method="post">
    Nombre:
    <input type="text" name="nombre"><br>
    Email: 
    <input type="text" name="email"><br>

    Enviar:
    <input type="submit" name="registrar" value="Enviar">
        
    </form>

    
</html>

<?php  

// comprobamos si existe $data

if (isset($data)){
    echo "Hay errores en el formulario";
}

?>