<?php
include_once ("Database/Database.php");
class ProductoDAO {


public $con_BD;


public function __construct (){
    $this->con_BD=Database::connect();
}


public function getAllProducts(){
    try{
        $stmt=$this->con_BD->prepare("Select * From productos");
        $stmt->execute();
        return $stmt->fetchAll();
    }catch (PDOException $e){
            return -1; // Error al realizar la consulta a B
    }
}


public function getProductById ($id){
    $stmt= $this->con_BD->prepare("Select * from productos where id_producto=$id");
    
    $stmt->setFetchMode(PDO::FETCH_ASSOC);

    $stmt->execute();

    return $stmt->fetch();        
}

}
?>